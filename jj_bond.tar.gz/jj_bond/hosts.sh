#!/bin/bash
echo "################  批量分发公钥-免交互方式  ####################"
# 调用这个文件
. /etc/init.d/functions 

# create key pair
rm -fr /root/.ssh/id_rsa*
ssh-keygen -t rsa -f /root/.ssh/id_rsa -P "" -q

IPtest=`cat /root/magic/ip.txt`

# 批量推送key文件
for ip in $IPtest      
do
echo "=======批量推送key=========="    
# 前提是密码统一的情况
echo $ip
sshpass -pBK#6u12G+rARoVoc-+9 ssh-copy-id -i /root/.ssh/id_rsa.pub root@$ip -o StrictHostKeyChecking=no &>/dev/null

if [ $? -eq 0 ]
then
action "主机$ip         [分发成功]"  /bin/true
else
action "主机$ip         [分发失败] " /bin/false
fi
done

# 批量推送hosts
for ip in $IPtest
do
echo $ip
echo "=======批量推送hosts=========="   
scp /root/magic/config/Kcsh/hosts root@$ip:/etc/hosts

if [ $? -eq 0 ]
then
action "主机$ip         [推送成功]"  /bin/true
else
action "主机$ip         [推送失败] " /bin/false
fi
done

echo "本机配置ssh免密..."

rm -f /root/.ssh/id_rsa 
ssh-keygen -f /root/.ssh/id_rsa -P ''
export SSHPASS=123456
source /root/magic/config/environment.sh
for HOST in ${NODE_IPS[@]};do
     sshpass -e ssh-copy-id -o StrictHostKeyChecking=no $HOST
done

