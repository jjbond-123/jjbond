TOKEN=`head -c 32 /dev/urandom | base64`

cat  > /home/encryption-config.yaml <<EOF
kind: EncryptionConfig
apiVersion: v1
resources:
  - resources:
      - secrets
    providers:
      - aescbc:
          keys:
            - name: key1
              secret: $TOKEN
      - identity: {}
EOF

cat > /home/token.csv <<EOF
$TOKEN,kubelet-bootstrap,10001,"system:kubelet-bootstrap"
EOF
